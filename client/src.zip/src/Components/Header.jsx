import React from "react";
import "../Components/css/Header.css";
import { useEffect, useState } from "react";

const Header = () => {
  return (
    <div>
      <div id="main-navbar" className="navbar">
        <h2 className="logo">Sand</h2>

        <nav>
          <ul className="hul">
            <li>
              <img
                src="./../assets/logo.png"
                alt="Logo"
                style={{
                  position: "relative",
                  right: "450px",
                  height: "50px",
                }}
              />
            </li>
            <li className="hli">
              <a
                className="ha"
                href="/"
                style={{
                  position: "relative",
                  right: "200px",
                }}
              >
                <i
                  className="fa-solid fa-envelope"
                  style={{ paddingRight: "10px" }}
                ></i>
                Company@email.com
              </a>
            </li>
            <li className="hli">
              <a
                className="ha"
                href="/"
                style={{
                  position: "relative",
                  right: "200px",
                }}
              >
                <i
                  class="fa-solid fa-phone"
                  style={{ paddingRight: "10px" }}
                ></i>
                9876543210
              </a>
            </li>
            <li className="hli">
              <a className="ha border p-2 size-1 rounded-full" href="/">
                <i class="fa-solid fa-user w-5"></i>
              </a>
            </li>
            {/* <li className="hli">
            <a className="ha" href="/home">Home</a>
          </li>
          <li className="hli">
            <a className="ha" href="/home">Home</a>
          </li>
          <li className="hli">
            <a className="ha" href="/home">Home</a>
          </li> */}
          </ul>
        </nav>
      </div>
    </div>
  );
};

export default Header;
