import React, { useState } from "react";
import { Outlet, Link } from "react-router-dom";

// Adjust the path

const Sidebar = ({ logoImage }) => {
  const [open, setOpen] = useState(true);
  const [isOpenS, setIsOpenS] = useState(false);
  const [isOpenS2, setIsOpenS2] = useState(false);
  const [isOpenP, setIsOpenP] = useState(false);
  const [isOpenP2, setIsOpenP2] = useState(false);
  const [isOpenI, setIsOpenI] = useState(false);
  const [isOpenP3, setIsOpenP3] = useState(false);

  return (
    <div className="flex">
      <div
        className={` ${
          open ? "w-60" : "w-20 "
        } bg-dark-purple max-h-full p-5 z-50  relative  duration-300`}
      >
        <img
          src="../../assets/control.png"
          className={`absolute cursor-pointer -right-3 top-9 w-7 border-dark-purple
          border-2 rounded-full  ${!open && "rotate-180"}`}
          onClick={() => setOpen(!open)}
        />
        <div className="flex gap-x-4 items-center"></div>
        {/* <h2 className="font-seriftext-black-300 text-xl text-center">Inventory</h2> */}
        <ul className="">
          <li
            className={`flex  rounded-md p-2 cursor-pointer text-black  items-center gap-x-4
              mt-2 hover:bg-amber-200`}
          >
            <h1 className={`${!open && "hidden"} origin-left duration-200`}>
              Admin
            </h1>
          </li>

          <Link to="/dashboard">
            <li
              className={`flex  rounded-md p-2 cursor-pointer text-black-300 text-sm items-center gap-x-4
              mt-2 hover:bg-amber-200`}
            >
              <i
                class="fa-solid fa-chart-simple"
                style={{ color: "black" }}
              ></i>
              <span className={`${!open && "hidden"} origin-left duration-200`}>
                Dashboard
              </span>
            </li>
          </Link>
          <li
            className={`flex  rounded-md p-2 cursor-pointer text-black-300 text-sm items-center gap-x-4
              mt-2 hover:bg-amber-200`}
          >
            <i class="fa-solid fa-cubes" style={{ color: "black" }}></i>
            <span className={`${!open && "hidden"} origin-left duration-200`}>
              <button onClick={() => setIsOpenP2((prev) => !prev)}>
                Projects
                {!isOpenP2 ? (
                  <i
                    className="fa-solid fa-caret-down pl-3"
                    style={{ color: "black" }}
                  ></i>
                ) : (
                  <i
                    className="fa-solid fa-caret-up pl-3"
                    style={{ color: "black" }}
                  ></i>
                )}
              </button>
            </span>
          </li>
          {isOpenP2 && (
            <ul className="transition-all duration-300 opacity-100">
              <Link to="/Products">
                <li
                  className={`flex rounded-md p-2 pl-10 cursor-pointertext-black-300 text-sm items-center gap-x-4 mt-2 hover:bg-amber-200 `}
                >
                  <i className="fa-solid fa-caret-right"></i>{" "}
                  <span
                    className={`${!open && "hidden"} origin-left duration-200`}
                  >
                    <button>Add Projects</button>
                  </span>
                </li>
              </Link>
              <Link to="/AddCategory">
                <li
                  className={`flex rounded-md p-2 pl-10 cursor-pointer text-black-300 text-sm items-center gap-x-4 mt-2 hover:bg-amber-200 `}
                >
                  <i className="fa-solid fa-caret-right"></i>{" "}
                  <span
                    className={`${!open && "hidden"} origin-left duration-200`}
                  >
                    <button>Manage Projects</button>
                  </span>
                </li>
              </Link>
            </ul>
          )}
          <li
            className={`flex  rounded-md p-2 cursor-pointer  text-black-300 text-sm items-center gap-x-4
              mt-2 hover:bg-amber-200`}
          >
            <i class="fa-solid fa-cubes" style={{ color: "black" }}></i>
            <span className={`${!open && "hidden"} origin-left duration-200`}>
              <button onClick={() => setIsOpenP3((prev) => !prev)}>
                Purchase
                {!isOpenP3 ? (
                  <i
                    className="fa-solid fa-caret-down pl-3"
                    style={{ color: "black" }}
                  ></i>
                ) : (
                  <i
                    className="fa-solid fa-caret-up pl-3"
                    style={{ color: "black" }}
                  ></i>
                )}
              </button>
            </span>
          </li>
          {isOpenP3 && (
            <ul className="transition-all duration-300 opacity-100">
              <Link to="/InventorySummary">
                <li
                  className={`flex rounded-md p-2 pl-10 cursor-pointer text-black-300 text-sm items-center gap-x-4 mt-2 hover:bg-amber-200 `}
                >
                  <i className="fa-solid fa-caret-right"></i>{" "}
                  <span
                    className={`${!open && "hidden"} origin-left duration-200`}
                  >
                    <button>Add Purchase</button>
                  </span>
                </li>
              </Link>

              <Link to="/ONHAND">
                <li
                  className={`flex rounded-md p-2 pl-10 cursor-pointer text-black-300 text-sm items-center gap-x-4 mt-2 hover:bg-amber-200 `}
                >
                  <i className="fa-solid fa-caret-right"></i>{" "}
                  <span
                    className={`${!open && "hidden"} origin-left duration-200`}
                  >
                    <button>Manage Purchase</button>
                  </span>
                </li>
              </Link>
            </ul>
          )}

          <Link to="/Sales">
            <li
              className={`flex  rounded-md p-2 cursor-pointer text-black-300 text-sm items-center gap-x-4
              mt-2 hover:bg-amber-200`}
            >
              <i
                class="fa-solid fa-cart-shopping"
                style={{ color: "black" }}
              ></i>
              <span className={`${!open && "hidden"} origin-left duration-200`}>
                Inventory
              </span>
            </li>
          </Link>
          <Link to="/Purchase_Order">
            <li
              className={`flex  rounded-md p-2 cursor-pointer text-black-300 text-sm items-center gap-x-4
              mt-2 hover:bg-amber-200`}
            >
              <i class="fa-solid fa-message" style={{ color: "black" }}></i>
              <span className={`${!open && "hidden"} origin-left duration-200`}>
                Proposal Making
              </span>
            </li>
          </Link>
          <Link to="/Manage_Sales">
            <li
              className={`flex  rounded-md p-2 cursor-pointer text-black-300 text-sm items-center gap-x-4
              mt-2 hover:bg-amber-200`}
            >
              <i class="fa-solid fa-message" style={{ color: "black" }}></i>
              <span className={`${!open && "hidden"} origin-left duration-200`}>
                Invoice
              </span>
            </li>
          </Link>

          <Link to="/vendors">
            <li
              className={`flex  rounded-md p-2 cursor-pointer text-black-300 text-sm items-center gap-x-4
              mt-2 hover:bg-amber-200`}
            >
              <i class="fa-solid fa-user" style={{ color: "black" }}></i>
              <span className={`${!open && "hidden"} origin-left duration-200`}>
                Users
              </span>
            </li>
          </Link>
          <Link to="/Products">
            <li
              className={`flex  rounded-md p-2 cursor-pointer text-black-300 text-sm items-center gap-x-4
              mt-2 hover:bg-amber-200`}
            >
              <i
                class="fa-solid fa-file-invoice"
                style={{ color: "black" }}
              ></i>
              <span className={`${!open && "hidden"} origin-left duration-200`}>
                Employees
              </span>
            </li>
          </Link>

          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />
        </ul>
      </div>

      <Outlet />
    </div>
  );
};

export default Sidebar;
