import React from 'react'
import './Css/Login.css'

const Login = () => {
  return (
  <section>
  <div className="content">

    <div className="left">
      <img src="https://i.postimg.cc/8CCmX23W/icon.png" alt="icon"/>
      <h1>VIBELY</h1>
    </div>

    <div className="right">
      <div className="title">
        <h2>Welcome to Vibely</h2>
      </div>
      <div className="form">
        <form>
          <div className="inputbox">
            <label>Full Name</label>
            <input type="text" placeholder="Enter your Name" required/>
          </div>
          <div className="inputbox">
            <label>Email</label>
            <input type="email" placeholder="Enter your Email ID" required/>
          </div>
          <div className="inputbox">
            <label>Password</label>
            <input type="password" placeholder="Enter your Password" required/>
          </div>
          <div className="create">
            <button type="submit">Create Account</button>
          </div>
          <div className="additional">
            <p>Already have an account ? <span>Log In</span></p>
          </div>
        </form>
        <div className="or">
          <h3>OR</h3>
          <div className="sign">
            <button>
              <ion-icon name="logo-google"></ion-icon> <span>Sign Up with Google</span>
            </button>
            <button>
              <ion-icon name="logo-github"></ion-icon> <span>Sign Up with GitHub</span>
            </button>
          </div>
        </div>
      </div>
    </div>

  </div>
</section>
  );
}

export default Login